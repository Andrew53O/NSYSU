
For commands supported by this shell please refer to "Design_document.md" file

# Testing Procedures

## Prerequisites
- clang

## Start building

1. run `clang andrewshell.c -o andrewshell`
2. run `./andrewshell`
3. In this step it will already go to my shell




